<p align="center">
  <img alt="Pyrrh1c" src="https://user-images.githubusercontent.com/44352871/108849753-86ba9200-75b0-11eb-9502-b8dc2e52445c.jpg" width="120" height="120">
</p>

# Start-RdpSessionTakeover
A short script to automate the process of RDP session hijacking.
When run without any parameters it will enumerate all existing RDP sessions and prompt for a session to be taken over.
This script requires local admin to run.

## Main Features
* Easy enumeration of sessions
* Automatic configuration of RDP shadowing
* Fast and easy lateral movement and privelege escalation 

## When To Use This Script
Perhaps you've owned a users who is a local administrator of a server. Another user who is a domain admin has a session on that server. With this you can quickly and easily begin viewing and/or interacting with their RDP session.
